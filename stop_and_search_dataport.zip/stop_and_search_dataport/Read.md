# Raw and Processed Stop-and-Search Dataset for London (April 2022 – May 2024)

This repository contains both raw and processed versions of publicly available Metropolitan Police stop-and-search data for London covering the period from April 2022 to May 2024.

## Raw Data
The raw_data directory contains 24 CSV files obtained directly from the police data website. Each file corresponds to a specific monthly extract of stop-and-search records within the study period (April 2022 – May 2024). The raw files are provided in their original form, prior to any cleaning or preprocessing.

## Processed Data
The processed_data directory contains the final cleaned and preprocessed dataset used in the associated manuscript. This dataset was created by merging the monthly raw files and applying data cleaning, missing value handling, feature engineering, and outcome grouping steps as described in the paper.

## Usage
Users may analyse the raw monthly data independently or use the processed dataset to reproduce the analyses reported in the associated manuscript. The data can be analysed using Python and standard data science libraries such as pandas and scikit-learn.

## Notes
The processed dataset represents the exact version used for the statistical analysis and machine learning experiments reported in the study.
